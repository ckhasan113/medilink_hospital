package com.example.hospitalapp.pojo;

import java.io.Serializable;

public class DoctorDetails implements Serializable {

    private String doctorID;

    private String image;
    private String name;
    private String degree;
    private String speciality;
    private String registrationNumber;
    private String sat;
    private String sun;
    private String mon;
    private String tue;
    private String wed;
    private String thu;
    private String fri;
    private String startTime;
    private String endTime;
    private String patientCount;
    private String block;
    private String floor;
    private String room;
    private String phone;
    private String fees;

    public DoctorDetails() {
    }

    public DoctorDetails(String doctorID, String image, String name, String degree, String speciality, String registrationNumber, String sat, String sun, String mon, String tue, String wed, String thu, String fri, String startTime, String endTime, String patientCount, String block, String floor, String room, String phone, String fees) {
        this.doctorID = doctorID;
        this.image = image;
        this.name = name;
        this.degree = degree;
        this.speciality = speciality;
        this.registrationNumber = registrationNumber;
        this.sat = sat;
        this.sun = sun;
        this.mon = mon;
        this.tue = tue;
        this.wed = wed;
        this.thu = thu;
        this.fri = fri;
        this.startTime = startTime;
        this.endTime = endTime;
        this.patientCount = patientCount;
        this.block = block;
        this.floor = floor;
        this.room = room;
        this.phone = phone;
        this.fees = fees;
    }

    public DoctorDetails(String image, String name, String degree, String speciality, String registrationNumber, String sat, String sun, String mon, String tue, String wed, String thu, String fri, String startTime, String endTime, String patientCount, String block, String floor, String room, String phone, String fees) {
        this.image = image;
        this.name = name;
        this.degree = degree;
        this.speciality = speciality;
        this.registrationNumber = registrationNumber;
        this.sat = sat;
        this.sun = sun;
        this.mon = mon;
        this.tue = tue;
        this.wed = wed;
        this.thu = thu;
        this.fri = fri;
        this.startTime = startTime;
        this.endTime = endTime;
        this.patientCount = patientCount;
        this.block = block;
        this.floor = floor;
        this.room = room;
        this.phone = phone;
        this.fees = fees;
    }

    public String getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(String doctorID) {
        this.doctorID = doctorID;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getSat() {
        return sat;
    }

    public void setSat(String sat) {
        this.sat = sat;
    }

    public String getSun() {
        return sun;
    }

    public void setSun(String sun) {
        this.sun = sun;
    }

    public String getMon() {
        return mon;
    }

    public void setMon(String mon) {
        this.mon = mon;
    }

    public String getTue() {
        return tue;
    }

    public void setTue(String tue) {
        this.tue = tue;
    }

    public String getWed() {
        return wed;
    }

    public void setWed(String wed) {
        this.wed = wed;
    }

    public String getThu() {
        return thu;
    }

    public void setThu(String thu) {
        this.thu = thu;
    }

    public String getFri() {
        return fri;
    }

    public void setFri(String fri) {
        this.fri = fri;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getPatientCount() {
        return patientCount;
    }

    public void setPatientCount(String patientCount) {
        this.patientCount = patientCount;
    }

    public String getBlock() {
        return block;
    }

    public void setBlock(String block) {
        this.block = block;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFees() {
        return fees;
    }

    public void setFees(String fees) {
        this.fees = fees;
    }
}